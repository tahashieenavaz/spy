# Spy!

### Introduction

Let me explain this game. Before anything else.
Spy is a game introduced to me by @tahashieenavaz.
The game players' are separated into two teams.
**Spies** and **regular players**.

Regular players should try to find spies with ambiguous question. And spies will constantly try to find the word regular players are making questions for.

### Screenshots

<p align="center">
    <img src="https://raw.githubusercontent.com/tahashieenavaz/spy/main/screenshots/homepage.jpeg" alt="Homepage" width="200"/>
    <img src="https://raw.githubusercontent.com/tahashieenavaz/spy/main/screenshots/settings-page.jpeg" alt="Settings Page" width="200"/>
</p>
<p align="center">
    <img src="https://raw.githubusercontent.com/tahashieenavaz/spy/main/screenshots/cards.jpeg" alt="Cards Page" width="200"/>
    <img src="https://raw.githubusercontent.com/tahashieenavaz/spy/main/screenshots/revealed-card.jpeg" alt="Revealed Card" width="200"/>
</p>

<p align="center">
    <img src="https://raw.githubusercontent.com/tahashieenavaz/spy/main/screenshots/sidebar.jpeg" alt="Sidebar" width="200"/>
</p>
